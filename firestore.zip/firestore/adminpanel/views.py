from django.shortcuts import render
from .forms import RegistrationModelForm
from .models import Registration
#import pyrebase
import firebase_admin
from firebase_admin import credentials , firestore
#from google.cloud import firestore
# Create your views here.
'''
config ={
  "type": "service_account",
  "project_id": "spotline-17b7f",
  "private_key_id": "f829705559d23a69c422305b8f1d7fdf3a9a44fa",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC+3InW5nv6VdK5\nhIwplScktgDb3AQhZ3eig6t3IJk8qc5vVDT8mQBVHi5HOqzRWXRG60+Q3C6LjT8l\n1g8Tdo7097Cp4HcRTBeaH9THt7y4CBIcNJKhn5qV5r8z1BmltCFWNjn6LuU3Qgg3\nxe6Rs2+2fL2dSnnwAurVSJ9Df1kAI7gvFcGQPGHXfDa0U+rq3vQzBkUmQRVkAgZ/\nN+1zK9vhl0ABpdXUkCDSITxpjFb4uPcP2Y5Pt+95Re8J3C5betre5T0Ygv9iUiYP\nujXnD6MFWHomHkrSTPtxLuz2kAv9zzqjd3o8FsQp/cgbAECpe3tCncqicbknoCkb\nOusadmTNAgMBAAECggEAK2MS6olGkafE2WtqOWGwnkXJeDFRtw5AQe9QoSoF66Zm\nSSSJTwqw6qiLuKF7+7MsHZsMYU/MPOkE++LnVnNTGBjeTh+6sXHsw5qM0kHQYr1i\n8Ip68sbHa2AjAvMqSWLjWSfGkjrq3F7kY1lZXEHAGWnN6N2vToI7Q/TYT425e7A+\nfE7Xv7LmypsYTpe+ecV0u9MW/tPkAgOlRiQi3ykBuOUwfPObj2Z/RFD4BDumsNnN\nxTKsSNoDKJjkl/YE4GXQJzIUKOnewaauN2vP0uG+LTrE08MPKlTyCWKQGS8zK/Ux\nsjOKPULzAQABQV3LJlolVOAC8/8DObJrQmJAbeTMOQKBgQDi1uxtIul8JnaGX9FZ\n2wGX8DQvkmqcLQc6s0Vru0XIi8fGQFPUazC9ibhvw7BNNE+2OOAGWxsOYImuHvP5\n3os2O3cwzeMwvKpBwe0bQspAKLsttTdY43ivfMXMmWfjXqu/LeJFpCHasobrdgBs\nYkmSvSZUZuy67dIM00v50cnq2wKBgQDXZZxJWf+VR/bTmJcZirGRcG3AugnoFZ2A\nd8IZvF5YT78GPsIi5vLhMI36k3HLNeq80ZsZcHdrRqYZyxKZfE4+/20qYUWH2/ck\n+x0W0KV1TNdGWVQLX/99Xmwxp6RsegQTpZtQsSliyHwDNxNXP5PcGOmZAwVMbtbt\nJmZJBTl7dwKBgDo4ucQlQtJXuPIyY7Rxbs5Fm89eADkHoaRiYP4OuhGINwVee2W5\nAXCUiZ8+FeEq/Q6jOHTJK3+cLZpgXXSTtx17U9NV9OsMcZKhKK9njCu9iJVpvsP0\n1oQMPWSPN0f3g5N1Pm9rejj8u35x8hfffkzIea8OH9K2ucQK86QyQWYjAoGBAL3i\nzu9/Tqico4UQPQyAT1/m3GqN11PpUktByDSF8ioqSz3HL8AzFyTceB3Rw/ygUIsa\nwX+gvTYuNxoAAyqaAiTZarR0wiYuDWdllNRbJbIOBq326/eHLqWoCvuPTY1v1442\nbYCqXdC+60yuTfeZjdD3iV+h4Rbrk7/HHV78IxurAoGAXtrKmTydxPFJaWA4UOpQ\nGAWi4tkBIIWmKWc7M++GSq1LgZJfon4eyShatnUTwJd8GTX1QKjB8LLukmwe4xpy\nmwr7WPEe/c0ESX+gNDa3mh0/KTTpcsaKKXO59Gu/eSUIyVFz7AWXXPBJka7UrfQP\n9GBrSiZqb4rx9L0X1LcBd20=\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-soutg@spotline-17b7f.iam.gserviceaccount.com",
  "client_id": "112201472598539467705",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-soutg%40spotline-17b7f.iam.gserviceaccount.com",
    'serviceAccount': "/media/cheese/ALL FILES/spotline-17b7f-firebase-adminsdk-soutg-f829705559.json"
}
'''
#initializing credentials

cred = credentials.Certificate("/media/cheese/ALL FILES/spotline-17b7f-firebase-adminsdk-soutg-8c8ef176a0.json")
firebase_admin.initialize_app(cred)
firebase_admin.get_app()
db = firestore.client()


def index(request):
    form = RegistrationModelForm()
    if request.method=='POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password1')
        confirmpassword = request.POST.get('password2')
        saving = Registration(username = username , email=email,password=password,confirmpassword=confirmpassword)
        saving.save()
        #user_data = db.collections(u'chats')
        #getting the data just for testing purpose
        '''
        doc_ref = db.collection(u'chats').document()

        doc = doc_ref.get()
        if doc.exists:
            print(f'Document data: {doc.to_dict()}')
        else:
            print(u'No such document!')
            #print(user_data)
        '''
        data = {
            u'username' : username,
            u'email':email,
            u'password' : password,
        }
        #adding the new doc 
        
        db.collection(u'chats').document().set(data)
    return render(request,'registration/register.html',{'form':form})

def registration(request):
    pass
    
    